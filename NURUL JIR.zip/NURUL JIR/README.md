# arta
Love Orang Hitam
